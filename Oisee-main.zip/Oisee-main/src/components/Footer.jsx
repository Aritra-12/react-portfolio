import React from 'react'


 
const Footer = () => {
    return (
        <div>
            <hr/>
            <p className="footer-text"> <h6>MMO</h6>
                <br></br><br></br>
            <b> Copyright &copy; 2021 MMO </b><br></br>
               
            </p>
        </div>
    )
}

export default Footer

