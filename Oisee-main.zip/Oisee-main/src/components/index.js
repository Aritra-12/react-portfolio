export { default as Home } from './Home';
export { default as Skills } from './Skills';
export { default as Experience } from './Experience';
export { default as About } from './About';
export { default as Contact } from './Contact';
export { default as Footer } from './Footer';
export { default as Team } from './Team';
